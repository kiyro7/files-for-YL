from flask import Flask

app = Flask(__name__)


@app.route("/")
def main_page():
    return "<h1>Миссия Колонизация Марса!</h1>"


@app.route("/index")
def index():
    return "<h1>И на Марсе будут яблони цвести!</h1>"


@app.route("/carousel")
def carousel():
    return """
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
        rel="stylesheet" 
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
        crossorigin="anonymous">
    <title>Классные</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>

        <div id="#myCarousel" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">

            <div class="carousel-item active" data-interval="4500">
              <img class="img-fluid" src="static/img/1.jpg" alt="1 slide">
            </div>
            <div class="carousel-item" data-interval="8000">
              <img class="img-fluid" src="static/img/2.jpg" alt="2 slide">
            </div>
            <div class="carousel-item" data-interval="6500">
              <img class="img-fluid" src="static/img/3.jpg" alt="3 slide">
            </div>
            <div class="carousel-item" data-interval="6000">
              <img class="img-fluid" src="static/img/4.jpg" alt="4 slide">
            </div>
            <div class="carousel-item" data-interval="6000">
              <img class="img-fluid" src="static/img/5.jpg" alt="5 slide">
            </div>
            <div class="carousel-item" data-interval="6500">
              <img class="img-fluid" src="static/img/6.jpg" alt="6 slide">
            </div>
            <div class="carousel-item" data-interval="6000">
              <img class="img-fluid" src="static/img/7.jpg" alt="7 slide">
            </div>
            <div class="carousel-item" data-interval="11000">
              <img class="img-fluid" src="static/img/8.jpg" alt="8 slide">
            </div>
            <div class="carousel-item" data-interval="5000">
              <img class="img-fluid" src="static/img/9.jpg" alt="9 slide">
            </div>
            <div class="carousel-item" data-interval="5200">
              <img class="img-fluid" src="static/img/10.jpg" alt="10 slide">
            </div>
            <div class="carousel-item" data-interval="4000">
              <img class="img-fluid" src="static/img/11.jpg" alt="11 slide">
            </div>

            </div>
            </div>
    </body>
    """


app.run()
